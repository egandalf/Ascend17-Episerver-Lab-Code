define("epi-cms/content-approval/command/RejectChanges", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "epi/i18n!epi/nls/episerver.cms.contentapproval.command.rejectchanges",
    // Parent class and mixins
    "epi/shell/widget/ValidationTextarea",
    "epi-cms/contentediting/command/_CommandWithDialogMixin",
    "epi-cms/content-approval/command/_ApprovalTransitionCommand"
],
function (
    declare,
    Deferred,
    localization,
    // Parent class and mixins
    ValidationTextarea,
    _CommandWithDialogMixin,
    _ApprovalTransitionCommand
) {

    return declare([_ApprovalTransitionCommand, _CommandWithDialogMixin], {
        // summary:
        //      Reject the changes in the current approval step
        // tags:
        //      internal

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: localization.label,

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconStop",

        // executeMethod: [public] String
        //      The method to execute on the approvalservice
        executeMethod: "rejectChanges",

        dialogContentClass: ValidationTextarea,

        dialogClass: "epi-dialog-confirm",

        confirmActionText: localization.confirmactiontext,

        title: localization.title,

        postscript: function () {
            this.inherited(arguments);

            this.dialogContentParams = {
                required: true,
                intermediateChanges: true,
                placeHolder: localization.placeholder,
                "class": "epi-textarea--max-height--500"
            };
        },

        _execute: function () {
            return this.approvalService.getDefinition(this.model.contentLink)
                .then(function (approvalDefinition) {
                    if (approvalDefinition.isCommentRequired) {
                        this._executeDeferred = new Deferred();
                        this.showDialog();
                        return this._executeDeferred.promise;
                    } else {
                        return this._executeServiceMethod();
                    }
                }.bind(this));
        },

        showDialog: function () {
            this.inherited(arguments);

            this._disableDeclineButton(true);

            this.dialogContent.on("change", function (value)  {
                this._disableDeclineButton(!value);
            }.bind(this));
        },

        _disableDeclineButton: function (disable) {
            // summary:
            //      Disables the decline button if the disable parameter is true.
            // tags:
            //      private

            this._dialog.onActionPropertyChanged({ name: this._dialog._okButtonName }, "disabled", disable);
        },

        onDialogExecute: function () {
            // summary:
            //      Resolves the execute promise after the dialog is executed.
            // tags:
            //      public virtual

            this.approval.rejectReason = this.dialogContent.value;
            this._executeDeferred.resolve(this._executeServiceMethod());
        },

        onDialogCancel: function () {
            // summary:
            //      Rejects the execute promise after the dialog is canceled.
            // tags:
            //      public virtual

            this._executeDeferred.reject();
        }
    });
});
